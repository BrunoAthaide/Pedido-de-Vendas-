package com.example.gerenciadordevendas.controller;

import android.content.Context;
import android.util.Log;

import com.example.gerenciadordevendas.dao.EnderecoDao;
import com.example.gerenciadordevendas.model.Endereco;

import java.util.List;

public class EnderecoController {
    private final EnderecoDao enderecoDao;

    // Construtor
    public EnderecoController(Context context) {
        enderecoDao = new EnderecoDao(context);
    }

    // Método para abrir conexão com o banco
    private void abrirBanco() {
        try {
            enderecoDao.open();
            Log.d("EnderecoController", "Banco de dados aberto com sucesso.");
        } catch (Exception e) {
            Log.e("EnderecoController", "Erro ao abrir o banco de dados", e);
        }
    }

    // Método para fechar conexão com o banco
    private void fecharBanco() {
        try {
            enderecoDao.close();
            Log.d("EnderecoController", "Banco de dados fechado com sucesso.");
        } catch (Exception e) {
            Log.e("EnderecoController", "Erro ao fechar o banco de dados", e);
        }
    }

    // Inserir novo endereço
    public long inserirEndereco(Endereco endereco) {
        long resultado = -1;
        try {
            abrirBanco();
            resultado = enderecoDao.inserirEndereco(endereco);
            Log.d("EnderecoController", "Endereço inserido com sucesso. ID: " + resultado);
        } catch (Exception e) {
            Log.e("EnderecoController", "Erro ao inserir endereço", e);
        } finally {
            fecharBanco();
        }
        return resultado;
    }

    // Atualizar um endereço existente
    public int atualizarEndereco(Endereco endereco) {
        int resultado = 0;
        try {
            abrirBanco();
            resultado = enderecoDao.atualizarEndereco(endereco);
            Log.d("EnderecoController", "Endereço atualizado com sucesso. ID: " + endereco.getCodigo());
        } catch (Exception e) {
            Log.e("EnderecoController", "Erro ao atualizar endereço", e);
        } finally {
            fecharBanco();
        }
        return resultado;
    }

    // Deletar um endereço pelo código
    public int deletarEndereco(long codigo) {
        int resultado = 0;
        try {
            abrirBanco();
            resultado = enderecoDao.deletarEndereco(codigo);
            Log.d("EnderecoController", "Endereço deletado com sucesso. ID: " + codigo);
        } catch (Exception e) {
            Log.e("EnderecoController", "Erro ao deletar endereço", e);
        } finally {
            fecharBanco();
        }
        return resultado;
    }

    // Buscar um endereço pelo código
    public Endereco buscarEndereco(long codigo) {
        Endereco endereco = null;
        try {
            abrirBanco();
            endereco = enderecoDao.buscarEndereco(codigo);
            if (endereco != null) {
                Log.d("EnderecoController", "Endereço encontrado: " + endereco.getRua());
            } else {
                Log.d("EnderecoController", "Endereço não encontrado. ID: " + codigo);
            }
        } catch (Exception e) {
            Log.e("EnderecoController", "Erro ao buscar endereço", e);
        } finally {
            fecharBanco();
        }
        return endereco;
    }

    // Listar todos os endereços
    public List<Endereco> listarTodosEnderecos() {
        List<Endereco> listaEnderecos = null;
        try {
            abrirBanco();
            listaEnderecos = enderecoDao.listarTodosEnderecos();
            Log.d("EnderecoController", "Lista de endereços carregada com sucesso.");
        } catch (Exception e) {
            Log.e("EnderecoController", "Erro ao listar endereços", e);
        } finally {
            fecharBanco();
        }
        return listaEnderecos;
    }

    // Método para salvar ou atualizar endereço
    public long salvarEndereco(Endereco endereco) {
        long resultado = -1;
        try {
            if (endereco.getCodigo() > 0) {
                // Atualiza se já existir um código válido
                resultado = atualizarEndereco(endereco);
                Log.d("EnderecoController", "Endereço atualizado. ID: " + endereco.getCodigo());
            } else {
                // Insere como novo endereço
                resultado = inserirEndereco(endereco);
                Log.d("EnderecoController", "Novo endereço inserido. ID: " + resultado);
            }
        } catch (Exception e) {
            Log.e("EnderecoController", "Erro ao salvar endereço", e);
        }
        return resultado;
    }

    // Método adicional para cálculo de frete
    public double calcularFrete(Endereco endereco) {
        double frete = 0.0;

        try {
            if (!endereco.getCidade().equalsIgnoreCase("Toledo") && endereco.getUf().equalsIgnoreCase("PR")) {
                frete = 20.0; // Frete dentro do estado do Paraná, mas fora de Toledo
            } else if (!endereco.getUf().equalsIgnoreCase("PR")) {
                frete = 50.0; // Frete para fora do estado do Paraná
            }

            Log.d("EnderecoController", "Frete calculado: " + frete);
        } catch (Exception e) {
            Log.e("EnderecoController", "Erro ao calcular frete", e);
        }

        return frete; // Frete gratuito dentro de Toledo-PR
    }
}