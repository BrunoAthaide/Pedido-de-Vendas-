package com.example.gerenciadordevendas.dao;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;

import com.example.gerenciadordevendas.helper.DatabaseHelper;
import com.example.gerenciadordevendas.model.Pedido;

import java.util.ArrayList;
import java.util.List;

public class PedidoDao {

    private SQLiteDatabase database;
    private DatabaseHelper dbHelper;

    public PedidoDao(Context context) {
        dbHelper = new DatabaseHelper(context);
    }

    // Abrir conexão com o banco de dados
    public void open() throws SQLException {
        database = dbHelper.getWritableDatabase();
    }

    // Fechar conexão com o banco de dados
    public void close() {
        dbHelper.close();
    }

    // Inserir um novo pedido no banco
    public long inserirPedido(Pedido pedido) {
        ContentValues values = new ContentValues();
        values.put(DatabaseHelper.COLUNA_PEDIDO_CODIGOCLIENTE, pedido.getCodigoCliente());
        values.put(DatabaseHelper.COLUNA_PEDIDO_CODIGOENDERECO, pedido.getCodigoEndereco());
        values.put(DatabaseHelper.COLUNA_PEDIDO_DATAPEDIDO, pedido.getDataPedido());
        values.put(DatabaseHelper.COLUNA_PEDIDO_VALORTOTAL, pedido.getValorTotal());
        values.put(DatabaseHelper.COLUNA_PEDIDO_CONDICAOPAGAMENTO, pedido.getCondicaoPagamento());

        return database.insert(DatabaseHelper.TABELA_PEDIDO, null, values);
    }

    // Atualizar um pedido existente
    public int atualizarPedido(Pedido pedido) {
        ContentValues values = new ContentValues();
        values.put(DatabaseHelper.COLUNA_PEDIDO_CODIGOCLIENTE, pedido.getCodigoCliente());
        values.put(DatabaseHelper.COLUNA_PEDIDO_CODIGOENDERECO, pedido.getCodigoEndereco());
        values.put(DatabaseHelper.COLUNA_PEDIDO_DATAPEDIDO, pedido.getDataPedido());
        values.put(DatabaseHelper.COLUNA_PEDIDO_VALORTOTAL, pedido.getValorTotal());
        values.put(DatabaseHelper.COLUNA_PEDIDO_CONDICAOPAGAMENTO, pedido.getCondicaoPagamento());

        return database.update(
                DatabaseHelper.TABELA_PEDIDO,
                values,
                DatabaseHelper.COLUNA_PEDIDO_CODIGO + " = ?",
                new String[]{String.valueOf(pedido.getCodigo())}
        );
    }

    // Deletar um pedido pelo código
    public int deletarPedido(long codigo) {
        return database.delete(
                DatabaseHelper.TABELA_PEDIDO,
                DatabaseHelper.COLUNA_PEDIDO_CODIGO + " = ?",
                new String[]{String.valueOf(codigo)}
        );
    }

    // Buscar um pedido específico pelo código
    public Pedido buscarPedido(long codigo) {
        Cursor cursor = database.query(
                DatabaseHelper.TABELA_PEDIDO,
                null,
                DatabaseHelper.COLUNA_PEDIDO_CODIGO + " = ?",
                new String[]{String.valueOf(codigo)},
                null, null, null
        );

        if (cursor != null) {
            cursor.moveToFirst();
            Pedido pedido = cursorParaPedido(cursor);
            cursor.close();
            return pedido;
        }
        return null;
    }

    // Listar todos os pedidos
    public List<Pedido> listarTodosPedidos() {
        List<Pedido> listaPedidos = new ArrayList<>();
        Cursor cursor = database.query(
                DatabaseHelper.TABELA_PEDIDO,
                null, null, null, null, null, null
        );

        if (cursor != null) {
            while (cursor.moveToNext()) {
                Pedido pedido = cursorParaPedido(cursor);
                listaPedidos.add(pedido);
            }
            cursor.close();
        }
        return listaPedidos;
    }

    // Implementação correta do método listarTodos()
    public List<Pedido> listarTodos() {
        return listarTodosPedidos();
    }

    // Converter o cursor em um objeto Pedido
    private Pedido cursorParaPedido(Cursor cursor) {
        Pedido pedido = new Pedido();
        pedido.setCodigo((int) cursor.getLong(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUNA_PEDIDO_CODIGO)));
        pedido.setCodigoCliente((int) cursor.getLong(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUNA_PEDIDO_CODIGOCLIENTE)));
        pedido.setCodigoEndereco((int) cursor.getLong(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUNA_PEDIDO_CODIGOENDERECO)));
        pedido.setDataPedido(cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUNA_PEDIDO_DATAPEDIDO)));
        pedido.setValorTotal(cursor.getDouble(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUNA_PEDIDO_VALORTOTAL)));
        pedido.setCondicaoPagamento(cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUNA_PEDIDO_CONDICAOPAGAMENTO)));
        return pedido;
    }
}
