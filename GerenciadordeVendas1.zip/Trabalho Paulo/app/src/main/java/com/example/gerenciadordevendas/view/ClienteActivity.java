package com.example.gerenciadordevendas.view;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.example.gerenciadordevendas.R;
import com.example.gerenciadordevendas.controller.ClienteController;
import com.example.gerenciadordevendas.model.Cliente;

public class ClienteActivity extends AppCompatActivity {

    private EditText editNomeCliente, editCpfCliente, editDataNascCliente;
    private Button btnSalvarCliente;
    private ClienteController clienteController;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cliente);

        // Inicializando os componentes da interface
        editNomeCliente = findViewById(R.id.editNomeCliente);
        editCpfCliente = findViewById(R.id.editCpfCliente);
        editDataNascCliente = findViewById(R.id.editDataNascCliente);
        btnSalvarCliente = findViewById(R.id.btnSalvarCliente);

        // Inicializando o controlador
        clienteController = new ClienteController(this);

        // Configurar a ação do botão "Salvar"
        btnSalvarCliente.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                salvarCliente();
            }
        });
    }

    private void salvarCliente() {
        // Obter os valores dos campos
        String nome = editNomeCliente.getText().toString().trim();
        String cpf = editCpfCliente.getText().toString().trim();
        String dataNasc = editDataNascCliente.getText().toString().trim();

        // Validar os dados
        if (nome.isEmpty() || cpf.isEmpty() || dataNasc.isEmpty()) {
            Toast.makeText(this, "Preencha todos os campos!", Toast.LENGTH_SHORT).show();
            return;
        }

        // Criar um objeto Cliente
        Cliente cliente = new Cliente();
        cliente.setNome(nome);
        cliente.setCpf(cpf);
        cliente.setDataNasc(dataNasc);

        // Salvar o cliente usando o controller
        boolean sucesso = clienteController.salvarCliente(cliente);

        if (sucesso) {
            Toast.makeText(this, "Cliente salvo com sucesso!", Toast.LENGTH_SHORT).show();
            // Limpar os campos após o salvamento
            limparCampos();
        } else {
            Toast.makeText(this, "Erro ao salvar cliente!", Toast.LENGTH_SHORT).show();
        }
    }

    private void limparCampos() {
        editNomeCliente.setText("");
        editCpfCliente.setText("");
        editDataNascCliente.setText("");
        editNomeCliente.requestFocus();
    }
}
