package com.example.gerenciadordevendas.model;

public class ItemPedido {
    private int codigo;
    private int codigoPedido; // FK para Pedido
    private int codigoItem; // FK para Item
    private int quantidade;
    private double preco;
    private String nome;

    public ItemPedido(int codigo, int codigoPedido, int codigoItem, int quantidade, double preco, String nome) {
        this.codigo = codigo;
        this.codigoPedido = codigoPedido;
        this.codigoItem = codigoItem;
        this.quantidade = quantidade;
        this.preco = preco;
        this.nome = nome;
    }

    public ItemPedido() {
    }

    public int getCodigoPedido() {
        return codigoPedido;
    }

    public void setCodigoPedido(int codigoPedido) {
        this.codigoPedido = codigoPedido;
    }

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public int getCodigoItem() {
        return codigoItem;
    }

    public void setCodigoItem(int codigoItem) {
        this.codigoItem = codigoItem;
    }

    public int getQuantidade() {
        return quantidade;
    }

    public void setQuantidade(int quantidade) {
        this.quantidade = quantidade;
    }

    public double getPreco() {
        return preco;
    }

    public void setPreco(double preco) {
        this.preco = preco;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public double getPrecoUnitario() {
        return preco;
    }
}