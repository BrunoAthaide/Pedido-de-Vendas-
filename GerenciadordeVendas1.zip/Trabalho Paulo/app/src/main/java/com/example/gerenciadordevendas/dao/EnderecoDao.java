package com.example.gerenciadordevendas.dao;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;

import com.example.gerenciadordevendas.helper.DatabaseHelper;
import com.example.gerenciadordevendas.model.Endereco;

import java.util.ArrayList;
import java.util.List;

public class EnderecoDao {

    private SQLiteDatabase database;
    private final DatabaseHelper dbHelper;

    public EnderecoDao(Context context) {
        dbHelper = new DatabaseHelper(context);
    }

    // Abrir a conexão com o banco de dados
    public void open() throws SQLException {
        if (database == null || !database.isOpen()) {
            database = dbHelper.getWritableDatabase();
        }
    }

    // Fechar a conexão com o banco de dados
    public void close() {
        if (database != null && database.isOpen()) {
            database.close();
        }
    }

    // Inserir um novo endereço no banco de dados
    public long inserirEndereco(Endereco endereco) {
        open();
        ContentValues values = new ContentValues();
        values.put(DatabaseHelper.COLUNA_ENDERECO_LOGRADOURO, endereco.getLogradouro());
        values.put(DatabaseHelper.COLUNA_ENDERECO_NUMERO, endereco.getNumero());
        values.put(DatabaseHelper.COLUNA_ENDERECO_BAIRRO, endereco.getBairro());
        values.put(DatabaseHelper.COLUNA_ENDERECO_CIDADE, endereco.getCidade());
        values.put(DatabaseHelper.COLUNA_ENDERECO_UF, endereco.getUf());
        values.put(DatabaseHelper.COLUNA_ENDERECO_CODIGOCLIENTE, endereco.getCodigoCliente());
        long id = database.insert(DatabaseHelper.TABELA_ENDERECO, null, values);
        close();
        return id;
    }

    // Atualizar um endereço existente
    public int atualizarEndereco(Endereco endereco) {
        open();
        ContentValues values = new ContentValues();
        values.put(DatabaseHelper.COLUNA_ENDERECO_LOGRADOURO, endereco.getLogradouro());
        values.put(DatabaseHelper.COLUNA_ENDERECO_NUMERO, endereco.getNumero());
        values.put(DatabaseHelper.COLUNA_ENDERECO_BAIRRO, endereco.getBairro());
        values.put(DatabaseHelper.COLUNA_ENDERECO_CIDADE, endereco.getCidade());
        values.put(DatabaseHelper.COLUNA_ENDERECO_UF, endereco.getUf());
        values.put(DatabaseHelper.COLUNA_ENDERECO_CODIGOCLIENTE, endereco.getCodigoCliente());
        int rowsUpdated = database.update(DatabaseHelper.TABELA_ENDERECO, values,
                DatabaseHelper.COLUNA_ENDERECO_CODIGO + " = ?",
                new String[]{String.valueOf(endereco.getCodigo())});
        close();
        return rowsUpdated;
    }

    // Excluir um endereço do banco de dados
    public int deletarEndereco(long codigo) {
        open();
        int rowsDeleted = database.delete(DatabaseHelper.TABELA_ENDERECO,
                DatabaseHelper.COLUNA_ENDERECO_CODIGO + " = ?",
                new String[]{String.valueOf(codigo)});
        close();
        return rowsDeleted;
    }

    // Buscar um endereço pelo código
    public Endereco buscarEndereco(long codigo) {
        open();
        Cursor cursor = database.query(DatabaseHelper.TABELA_ENDERECO,
                null,
                DatabaseHelper.COLUNA_ENDERECO_CODIGO + " = ?",
                new String[]{String.valueOf(codigo)},
                null, null, null);

        Endereco endereco = null;
        if (cursor != null && cursor.moveToFirst()) {
            endereco = cursorParaEndereco(cursor);
            cursor.close();
        }
        close();
        return endereco;
    }

    // Listar todos os endereços do banco de dados
    public List<Endereco> listarTodosEnderecos() {
        open();
        List<Endereco> enderecos = new ArrayList<>();
        Cursor cursor = database.query(DatabaseHelper.TABELA_ENDERECO,
                null, null, null, null, null, null);

        if (cursor != null) {
            while (cursor.moveToNext()) {
                enderecos.add(cursorParaEndereco(cursor));
            }
            cursor.close();
        }
        close();
        return enderecos;
    }

    // Converter o cursor em um objeto Endereco
    private Endereco cursorParaEndereco(Cursor cursor) {
        Endereco endereco = new Endereco();
        endereco.setCodigo((int) cursor.getLong(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUNA_ENDERECO_CODIGO)));
        endereco.setLogradouro(cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUNA_ENDERECO_LOGRADOURO)));
        endereco.setNumero(cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUNA_ENDERECO_NUMERO)));
        endereco.setBairro(cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUNA_ENDERECO_BAIRRO)));
        endereco.setCidade(cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUNA_ENDERECO_CIDADE)));
        endereco.setUf(cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUNA_ENDERECO_UF)));
        endereco.setCodigoCliente(cursor.getInt(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUNA_ENDERECO_CODIGOCLIENTE)));
        return endereco;
    }
}
