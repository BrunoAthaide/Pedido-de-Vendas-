package com.example.gerenciadordevendas.model;

public class Cliente {
    private int codigo;
    private String nome;
    private String cpf;
    private String dataNasc;
    private String email;

    // Construtor padrão
    public Cliente() {
    }

    // Construtor completo
    public Cliente(int codigo, String nome, String cpf, String dataNasc, String email) {
        this.codigo = codigo;
        this.nome = nome;
        this.cpf = cpf;
        this.dataNasc = dataNasc;
        this.email = email;
    }

    // Construtor simplificado
    public Cliente(String nome) {
        this.nome = nome;
    }

    public Cliente(String s, String mail) {
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public String getDataNasc() {
        return dataNasc;
    }

    public void setDataNasc(String dataNasc) {
        this.dataNasc = dataNasc;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
}
