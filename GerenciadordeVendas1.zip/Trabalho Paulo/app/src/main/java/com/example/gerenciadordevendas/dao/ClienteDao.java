package com.example.gerenciadordevendas.dao;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

import com.example.gerenciadordevendas.helper.DatabaseHelper;
import com.example.gerenciadordevendas.model.Cliente;

import java.util.ArrayList;
import java.util.List;

public class ClienteDao implements IGenericDao<Cliente> {

    private SQLiteDatabase database;
    private final DatabaseHelper dbHelper;

    // Construtor
    public ClienteDao(Context context) {
        if (context == null) {
            throw new IllegalArgumentException("Context não pode ser nulo.");
        }
        dbHelper = new DatabaseHelper(context);
    }

    // Inserir cliente
    @Override
    public long inserir(Cliente cliente) {
        if (cliente == null) {
            Log.e("ClienteDao", "Cliente nulo ao tentar inserir.");
            return -1; // Retorna -1 para indicar erro
        }

        ContentValues values = new ContentValues();
        values.put(DatabaseHelper.COLUNA_CLIENTE_NOME, cliente.getNome());
        values.put(DatabaseHelper.COLUNA_CLIENTE_CPF, cliente.getCpf());
        values.put(DatabaseHelper.COLUNA_CLIENTE_DATANASC, cliente.getDataNasc());

        long id = -1;
        try {
            open();
            id = database.insert(DatabaseHelper.TABELA_CLIENTE, null, values);
        } catch (Exception e) {
            Log.e("ClienteDao", "Erro ao inserir cliente: " + e.getMessage(), e);
        } finally {
            close();
        }
        return id;
    }

    // Atualizar cliente
    @Override
    public int atualizar(Cliente cliente) {
        if (cliente == null) {
            Log.e("ClienteDao", "Cliente nulo ao tentar atualizar.");
            return 0; // Retorna 0 para indicar que nenhuma linha foi atualizada
        }

        ContentValues values = new ContentValues();
        values.put(DatabaseHelper.COLUNA_CLIENTE_NOME, cliente.getNome());
        values.put(DatabaseHelper.COLUNA_CLIENTE_CPF, cliente.getCpf());
        values.put(DatabaseHelper.COLUNA_CLIENTE_DATANASC, cliente.getDataNasc());

        int rowsUpdated = 0;
        try {
            open();
            rowsUpdated = database.update(
                    DatabaseHelper.TABELA_CLIENTE,
                    values,
                    DatabaseHelper.COLUNA_CLIENTE_CODIGO + " = ?",
                    new String[]{String.valueOf(cliente.getCodigo())}
            );
        } catch (Exception e) {
            Log.e("ClienteDao", "Erro ao atualizar cliente: " + e.getMessage(), e);
        } finally {
            close();
        }
        return rowsUpdated;
    }

    // Deletar cliente
    @Override
    public int deletar(long id) {
        int rowsDeleted = 0;
        try {
            open();
            rowsDeleted = database.delete(
                    DatabaseHelper.TABELA_CLIENTE,
                    DatabaseHelper.COLUNA_CLIENTE_CODIGO + " = ?",
                    new String[]{String.valueOf(id)}
            );
        } catch (Exception e) {
            Log.e("ClienteDao", "Erro ao deletar cliente: " + e.getMessage(), e);
        } finally {
            close();
        }
        return rowsDeleted;
    }

    // Buscar cliente por ID
    @Override
    public Cliente buscarPorId(long id) {
        Cliente cliente = null;
        Cursor cursor = null;
        try {
            open();
            cursor = database.query(
                    DatabaseHelper.TABELA_CLIENTE,
                    null,
                    DatabaseHelper.COLUNA_CLIENTE_CODIGO + " = ?",
                    new String[]{String.valueOf(id)},
                    null, null, null
            );

            if (cursor != null && cursor.moveToFirst()) {
                cliente = cursorParaCliente(cursor);
            }
        } catch (Exception e) {
            Log.e("ClienteDao", "Erro ao buscar cliente por ID: " + e.getMessage(), e);
        } finally {
            if (cursor != null) {
                cursor.close();
            }
            close();
        }
        return cliente;
    }

    // Listar todos os clientes
    @Override
    public List<Cliente> listarTodos() {
        List<Cliente> clientes = new ArrayList<>();
        Cursor cursor = null;
        try {
            open();
            cursor = database.query(
                    DatabaseHelper.TABELA_CLIENTE,
                    null, null, null, null, null, null
            );

            if (cursor != null) {
                while (cursor.moveToNext()) {
                    clientes.add(cursorParaCliente(cursor));
                }
            }
        } catch (Exception e) {
            Log.e("ClienteDao", "Erro ao listar clientes: " + e.getMessage(), e);
        } finally {
            if (cursor != null) {
                cursor.close();
            }
            close();
        }
        return clientes;
    }

    // Métodos auxiliares específicos (usam os genéricos já implementados)
    public long inserirCliente(Cliente cliente) {
        return inserir(cliente);
    }

    public int atualizarCliente(Cliente cliente) {
        return atualizar(cliente);
    }

    public int deletarCliente(long codigo) {
        return deletar(codigo);
    }

    public Cliente buscarCliente(long codigo) {
        return buscarPorId(codigo);
    }

    public List<Cliente> listarClientes() {
        return listarTodos();
    }

    // Conversão de cursor para Cliente
    private Cliente cursorParaCliente(Cursor cursor) {
        Cliente cliente = new Cliente();
        try {
            int codigoIndex = cursor.getColumnIndex(DatabaseHelper.COLUNA_CLIENTE_CODIGO);
            int nomeIndex = cursor.getColumnIndex(DatabaseHelper.COLUNA_CLIENTE_NOME);
            int cpfIndex = cursor.getColumnIndex(DatabaseHelper.COLUNA_CLIENTE_CPF);
            int dataNascIndex = cursor.getColumnIndex(DatabaseHelper.COLUNA_CLIENTE_DATANASC);

            if (codigoIndex != -1) {
                cliente.setCodigo(cursor.getInt(codigoIndex));
            }
            if (nomeIndex != -1) {
                cliente.setNome(cursor.getString(nomeIndex));
            }
            if (cpfIndex != -1) {
                cliente.setCpf(cursor.getString(cpfIndex));
            }
            if (dataNascIndex != -1) {
                cliente.setDataNasc(cursor.getString(dataNascIndex));
            }
        } catch (Exception e) {
            Log.e("ClienteDao", "Erro ao converter cursor para cliente: " + e.getMessage(), e);
        }
        return cliente;
    }

    // Abrir conexão com o banco
    public void open() throws SQLException {
        if (database == null || !database.isOpen()) {
            database = dbHelper.getWritableDatabase();
        }
    }

    // Fechar conexão com o banco
    public void close() {
        if (database != null && database.isOpen()) {
            database.close();
        }
    }
}