package com.example.gerenciadordevendas.controller;

import android.content.Context;
import android.util.Log;

import com.example.gerenciadordevendas.dao.ClienteDao;
import com.example.gerenciadordevendas.model.Cliente;

import java.util.List;

public class ClienteController {

    private final ClienteDao clienteDao;

    // Construtor
    public ClienteController(Context context) {
        this.clienteDao = new ClienteDao(context);
    }

    // Adicionar um cliente
    public long adicionarCliente(Cliente cliente) {
        long resultado = -1;
        try {
            clienteDao.open();
            resultado = clienteDao.inserirCliente(cliente);
            Log.d("ClienteController", "Cliente adicionado com ID: " + resultado);
        } catch (Exception e) {
            Log.e("ClienteController", "Erro ao adicionar cliente", e);
        } finally {
            clienteDao.close();
        }
        return resultado;
    }

    // Atualizar um cliente
    public int atualizarCliente(Cliente cliente) {
        int resultado = 0;
        try {
            clienteDao.open();
            resultado = clienteDao.atualizarCliente(cliente);
            Log.d("ClienteController", "Cliente atualizado com ID: " + cliente.getCodigo());
        } catch (Exception e) {
            Log.e("ClienteController", "Erro ao atualizar cliente", e);
        } finally {
            clienteDao.close();
        }
        return resultado;
    }

    // Deletar um cliente
    public int deletarCliente(long codigo) {
        int resultado = 0;
        try {
            clienteDao.open();
            resultado = clienteDao.deletarCliente(codigo);
            Log.d("ClienteController", "Cliente deletado com ID: " + codigo);
        } catch (Exception e) {
            Log.e("ClienteController", "Erro ao deletar cliente", e);
        } finally {
            clienteDao.close();
        }
        return resultado;
    }

    // Buscar um cliente específico
    public Cliente buscarCliente(long codigo) {
        Cliente cliente = null;
        try {
            clienteDao.open();
            cliente = clienteDao.buscarCliente(codigo);
            if (cliente != null) {
                Log.d("ClienteController", "Cliente encontrado: " + cliente.getNome());
            } else {
                Log.d("ClienteController", "Cliente não encontrado com ID: " + codigo);
            }
        } catch (Exception e) {
            Log.e("ClienteController", "Erro ao buscar cliente", e);
        } finally {
            clienteDao.close();
        }
        return cliente;
    }

    // Listar todos os clientes
    public List<Cliente> listarClientes() {
        List<Cliente> listaClientes = null;
        try {
            clienteDao.open();
            listaClientes = clienteDao.listarClientes();
            Log.d("ClienteController", "Lista de clientes carregada com sucesso");
        } catch (Exception e) {
            Log.e("ClienteController", "Erro ao listar clientes", e);
        } finally {
            clienteDao.close();
        }
        return listaClientes;
    }

    // Salvar um cliente (adiciona ou atualiza)
    public boolean salvarCliente(Cliente cliente) {
        boolean sucesso = false;

        // Validação básica
        if (cliente == null || cliente.getNome() == null || cliente.getNome().isEmpty()) {
            Log.e("ClienteController", "Cliente inválido! Nome não pode ser nulo ou vazio");
            return false;
        }

        try {
            clienteDao.open();
            if (cliente.getCodigo() != 0) {
                sucesso = clienteDao.atualizarCliente(cliente) > 0;
                Log.d("ClienteController", "Cliente atualizado: " + cliente.getNome());
            } else {
                sucesso = clienteDao.inserirCliente(cliente) != -1;
                Log.d("ClienteController", "Cliente adicionado: " + cliente.getNome());
            }
        } catch (Exception e) {
            Log.e("ClienteController", "Erro ao salvar cliente", e);
        } finally {
            clienteDao.close();
        }
        return sucesso;
    }
}