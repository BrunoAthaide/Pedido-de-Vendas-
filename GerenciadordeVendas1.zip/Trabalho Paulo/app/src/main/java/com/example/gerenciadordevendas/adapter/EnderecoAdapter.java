package com.example.gerenciadordevendas.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.example.gerenciadordevendas.R;
import com.example.gerenciadordevendas.model.Endereco;
import java.util.List;

public class EnderecoAdapter extends RecyclerView.Adapter<EnderecoAdapter.EnderecoViewHolder> {

    private List<Endereco> listaEnderecos;
    private Context context;
    private OnEnderecoClickListener listener;

    // Interface para manipular eventos de clique
    public interface OnEnderecoClickListener {
        void onEnderecoClick(Endereco endereco);
    }

    public EnderecoAdapter(List<Endereco> listaEnderecos, Context context, OnEnderecoClickListener listener) {
        this.listaEnderecos = listaEnderecos;
        this.context = context;
        this.listener = listener;
    }

    @NonNull
    @Override
    public EnderecoViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(context).inflate(R.layout.item_pedido, parent, false);
        return new EnderecoViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull EnderecoViewHolder holder, int position) {
        Endereco endereco = listaEnderecos.get(position);

        // Bind dos dados ao layout
        holder.tvRua.setText(endereco.getLogradouro());
        holder.tvNumero.setText(String.format("Número: %s", endereco.getNumero()));
        holder.tvBairro.setText(String.format("Bairro: %s", endereco.getBairro()));
        holder.tvCidade.setText(String.format("Cidade: %s", endereco.getCidade()));
        holder.tvEstado.setText(String.format("Estado: %s", endereco.getUf()));

        // Configurar o clique no item
        holder.itemView.setOnClickListener(v -> {
            if (listener != null) {
                listener.onEnderecoClick(endereco);
            }
        });
    }

    @Override
    public int getItemCount() {
        return listaEnderecos.size();
    }

    public static class EnderecoViewHolder extends RecyclerView.ViewHolder {
        TextView tvRua, tvNumero, tvBairro, tvCidade, tvEstado;

        public EnderecoViewHolder(@NonNull View itemView) {
            super(itemView);

            // Inicializar componentes do layout
            tvRua = itemView.findViewById(R.id.tvRua);
            tvNumero = itemView.findViewById(R.id.tvNumero);
            tvBairro = itemView.findViewById(R.id.tvBairro);
            tvCidade = itemView.findViewById(R.id.tvCidade);
            tvEstado = itemView.findViewById(R.id.tvEstado);
        }
    }
}
