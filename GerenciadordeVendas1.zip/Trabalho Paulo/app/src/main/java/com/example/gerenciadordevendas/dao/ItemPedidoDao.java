package com.example.gerenciadordevendas.dao;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;

import com.example.gerenciadordevendas.helper.DatabaseHelper;
import com.example.gerenciadordevendas.model.ItemPedido;

import java.util.ArrayList;
import java.util.List;

public class ItemPedidoDao {

    private SQLiteDatabase database;
    private DatabaseHelper dbHelper;

    public ItemPedidoDao(Context context) {
        dbHelper = new DatabaseHelper(context);
    }

    // Abrir conexão com o banco de dados
    public void open() throws SQLException {
        database = dbHelper.getWritableDatabase();
    }

    // Fechar conexão com o banco de dados
    public void close() {
        dbHelper.close();
    }

    // Inserir um novo item de pedido no banco
    public long inserirItemPedido(ItemPedido itemPedido) {
        ContentValues values = new ContentValues();
        values.put(DatabaseHelper.COLUNA_ITEMPEDIDO_CODIGOPEDIDO, itemPedido.getCodigoPedido());
        values.put(DatabaseHelper.COLUNA_ITEMPEDIDO_CODIGOITEM, itemPedido.getCodigoItem());
        values.put(DatabaseHelper.COLUNA_ITEMPEDIDO_QUANTIDADE, itemPedido.getQuantidade());

        return database.insert(DatabaseHelper.TABELA_ITEM_PEDIDO, null, values);
    }

    // Atualizar um item de pedido existente
    public int atualizarItemPedido(ItemPedido itemPedido) {
        ContentValues values = new ContentValues();
        values.put(DatabaseHelper.COLUNA_ITEMPEDIDO_CODIGOPEDIDO, itemPedido.getCodigoPedido());
        values.put(DatabaseHelper.COLUNA_ITEMPEDIDO_CODIGOITEM, itemPedido.getCodigoItem());
        values.put(DatabaseHelper.COLUNA_ITEMPEDIDO_QUANTIDADE, itemPedido.getQuantidade());

        return database.update(
                DatabaseHelper.TABELA_ITEM_PEDIDO,
                values,
                DatabaseHelper.COLUNA_ITEMPEDIDO_CODIGO + " = ?",
                new String[]{String.valueOf(itemPedido.getCodigo())}
        );
    }

    // Deletar um item de pedido pelo código
    public int deletarItemPedido(long codigo) {
        return database.delete(
                DatabaseHelper.TABELA_ITEM_PEDIDO,
                DatabaseHelper.COLUNA_ITEMPEDIDO_CODIGO + " = ?",
                new String[]{String.valueOf(codigo)}
        );
    }

    // Buscar um item de pedido específico pelo código
    public ItemPedido buscarItemPedido(long codigo) {
        Cursor cursor = database.query(
                DatabaseHelper.TABELA_ITEM_PEDIDO,
                null,
                DatabaseHelper.COLUNA_ITEMPEDIDO_CODIGO + " = ?",
                new String[]{String.valueOf(codigo)},
                null, null, null
        );

        if (cursor != null) {
            cursor.moveToFirst();
            ItemPedido itemPedido = cursorParaItemPedido(cursor);
            cursor.close();
            return itemPedido;
        }
        return null;
    }

    // Listar todos os itens de um pedido específico
    public List<ItemPedido> listarItensPorPedido(long codigoPedido) {
        List<ItemPedido> listaItens = new ArrayList<>();
        Cursor cursor = database.query(
                DatabaseHelper.TABELA_ITEM_PEDIDO,
                null,
                DatabaseHelper.COLUNA_ITEMPEDIDO_CODIGOPEDIDO + " = ?",
                new String[]{String.valueOf(codigoPedido)},
                null, null, null
        );

        if (cursor != null) {
            while (cursor.moveToNext()) {
                ItemPedido itemPedido = cursorParaItemPedido(cursor);
                listaItens.add(itemPedido);
            }
            cursor.close();
        }
        return listaItens;
    }

    // Converter o cursor em um objeto ItemPedido
    private ItemPedido cursorParaItemPedido(Cursor cursor) {
        ItemPedido itemPedido = new ItemPedido();
        itemPedido.setCodigo((int) cursor.getLong(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUNA_ITEMPEDIDO_CODIGO)));
        itemPedido.setCodigoPedido((int) cursor.getLong(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUNA_ITEMPEDIDO_CODIGOPEDIDO)));
        itemPedido.setCodigoItem((int) cursor.getLong(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUNA_ITEMPEDIDO_CODIGOITEM)));
        itemPedido.setQuantidade(cursor.getInt(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUNA_ITEMPEDIDO_QUANTIDADE)));
        return itemPedido;
    }
}
