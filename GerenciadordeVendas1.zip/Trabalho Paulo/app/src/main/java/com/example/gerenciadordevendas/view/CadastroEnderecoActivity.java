package com.example.gerenciadordevendas.view;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.example.gerenciadordevendas.R;
import com.example.gerenciadordevendas.controller.EnderecoController;
import com.example.gerenciadordevendas.model.Endereco;

public class CadastroEnderecoActivity extends AppCompatActivity {
    private EditText edtRua, edtNumero, edtBairro, edtCidade, edtEstado, edtCep;
    private Button btnSalvar, btnCancelar;
    private EnderecoController enderecoController;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cadastro_endereco);

        // Inicializar componentes do layout
        inicializarComponentes();

        // Inicializar o controller
        enderecoController = new EnderecoController(this);

        // Configurar ação dos botões
        configurarListeners();
    }

    private void inicializarComponentes() {
        edtRua = findViewById(R.id.edtRua);
        edtNumero = findViewById(R.id.edtNumero);
        edtBairro = findViewById(R.id.edtBairro);
        edtCidade = findViewById(R.id.edtCidade);
        edtEstado = findViewById(R.id.edtEstado);
        edtCep = findViewById(R.id.edtCep);

        btnSalvar = findViewById(R.id.btnSalvarEndereco);
        btnCancelar = findViewById(R.id.btnCancelarEndereco);

        if (edtRua == null || edtNumero == null || edtBairro == null || edtCidade == null || edtEstado == null || edtCep == null || btnSalvar == null || btnCancelar == null) {
            Log.e("CadastroEnderecoActivity", "Um ou mais componentes estão nulos após a inicialização.");
            return;
        }
    }

    private void configurarListeners() {
        btnSalvar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                salvarEndereco();
            }
        });

        btnCancelar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(CadastroEnderecoActivity.this, "Cadastro cancelado!", Toast.LENGTH_SHORT).show();
                finish(); // Fecha a Activity sem salvar
            }
        });
    }

    private void salvarEndereco() {
        String rua = edtRua.getText().toString().trim();
        String numero = edtNumero.getText().toString().trim();
        String bairro = edtBairro.getText().toString().trim();
        String cidade = edtCidade.getText().toString().trim();
        String estado = edtEstado.getText().toString().trim();
        String cep = edtCep.getText().toString().trim();

        if (rua.isEmpty() || numero.isEmpty() || bairro.isEmpty() || cidade.isEmpty() || estado.isEmpty() || cep.isEmpty()) {
            Toast.makeText(this, "Preencha todos os campos!", Toast.LENGTH_SHORT).show();
            return;
        }

        Endereco endereco = new Endereco(rua, numero, bairro, cidade, estado, cep);

        try {
            long resultado = enderecoController.salvarEndereco(endereco);

            if (resultado > 0) {
                Toast.makeText(this, "Endereço salvo com sucesso!", Toast.LENGTH_SHORT).show();
                Log.d("CadastroEnderecoActivity", "Endereço salvo com ID: " + resultado);
                finish();
            } else {
                Toast.makeText(this, "Erro ao salvar o endereço.", Toast.LENGTH_SHORT).show();
                Log.e("CadastroEnderecoActivity", "Erro ao salvar endereço no banco");
            }
        } catch (Exception e) {
            Toast.makeText(this, "Erro inesperado ao salvar o endereço.", Toast.LENGTH_SHORT).show();
            Log.e("CadastroEnderecoActivity", "Erro ao salvar endereço", e);
        }
    }
}