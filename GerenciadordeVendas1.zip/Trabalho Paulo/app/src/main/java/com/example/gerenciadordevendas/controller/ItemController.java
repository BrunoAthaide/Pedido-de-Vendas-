package com.example.gerenciadordevendas.controller;

import android.content.Context;
import com.example.gerenciadordevendas.dao.ItemDao;
import com.example.gerenciadordevendas.model.Item;
import java.util.List;

public class ItemController {
    private ItemDao itemDao;

    public ItemController(Context context) {
        itemDao = new ItemDao(context);
    }

    // Método para abrir conexão com o banco
    public void abrirBanco() {
        itemDao.open();
    }

    // Método para fechar conexão com o banco
    public void fecharBanco() {
        itemDao.close();
    }

    // Inserir novo item
    public long inserirItem(Item item) {
        abrirBanco();
        long resultado = itemDao.inserirItem(item);
        fecharBanco();
        return resultado;
    }

    // Atualizar um item existente
    public int atualizarItem(Item item) {
        abrirBanco();
        int resultado = itemDao.atualizarItem(item);
        fecharBanco();
        return resultado;
    }

    // Deletar um item pelo código
    public int deletarItem(long codigo) {
        abrirBanco();
        int resultado = itemDao.deletarItem(codigo);
        fecharBanco();
        return resultado;
    }

    // Listar todos os itens
    public List<Item> listarTodosItens() {
        abrirBanco();
        List<Item> listaItens = itemDao.listarTodosItens();
        fecharBanco();
        return listaItens;
    }
}
