package com.example.gerenciadordevendas.model;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class Pedido {

    private int codigo; // Código do pedido
    private int codigoCliente; // FK para Cliente
    private int codigoEndereco; // FK para Endereco
    private String dataPedido; // Data do pedido no formato String
    private double valorTotal; // Valor total do pedido
    private String condicaoPagamento; // Condição de pagamento (Ex: "À vista", "Parcelado")

    // Construtor com todos os atributos
    public Pedido(int codigo, int codigoCliente, int codigoEndereco, Date dataPedido, double valorTotal, String condicaoPagamento) {
        this.codigo = codigo;
        this.codigoCliente = codigoCliente;
        this.codigoEndereco = codigoEndereco;
        // Formata o objeto Date para String no formato "dd/MM/yyyy"
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy", Locale.getDefault());
        this.dataPedido = dateFormat.format(dataPedido);
        this.valorTotal = valorTotal;
        this.condicaoPagamento = condicaoPagamento;
    }

    // Construtor vazio (necessário para instanciar sem parâmetros)
    public Pedido() {
    }

    // Getters e Setters
    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public int getCodigoCliente() {
        return codigoCliente;
    }

    public void setCodigoCliente(int codigoCliente) {
        this.codigoCliente = codigoCliente;
    }

    public int getCodigoEndereco() {
        return codigoEndereco;
    }

    public void setCodigoEndereco(int codigoEndereco) {
        this.codigoEndereco = codigoEndereco;
    }

    public String getDataPedido() {
        return dataPedido;
    }

    public void setDataPedido(String dataPedido) {
        this.dataPedido = dataPedido;
    }

    public void setDataPedido(Date dataPedido) {
        // Adiciona sobrecarga para aceitar Date diretamente
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy", Locale.getDefault());
        this.dataPedido = dateFormat.format(dataPedido);
    }

    public double getValorTotal() {
        return valorTotal;
    }

    public void setValorTotal(double valorTotal) {
        this.valorTotal = valorTotal;
    }

    public String getCondicaoPagamento() {
        return condicaoPagamento;
    }

    public void setCondicaoPagamento(String condicaoPagamento) {
        this.condicaoPagamento = condicaoPagamento;
    }

    // Novo método getNumeroPedido
    public int getNumeroPedido() {
        return codigo; // O número do pedido é representado pelo código
    }
}
