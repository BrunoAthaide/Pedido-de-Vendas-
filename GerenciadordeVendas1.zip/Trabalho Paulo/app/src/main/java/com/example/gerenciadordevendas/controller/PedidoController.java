package com.example.gerenciadordevendas.controller;


import android.content.Context;

import com.example.gerenciadordevendas.dao.PedidoDao;
import com.example.gerenciadordevendas.model.Pedido;

import java.util.List;

public class PedidoController {

    private PedidoDao pedidoDao;

    public PedidoController(Context context) {
        pedidoDao = new PedidoDao(context);
    }

    public long adicionarPedido(Pedido pedido) {
        pedidoDao.open();
        long resultado = pedidoDao.inserirPedido(pedido);
        pedidoDao.close();
        return resultado;
    }

    public int atualizarPedido(Pedido pedido) {
        pedidoDao.open();
        int resultado = pedidoDao.atualizarPedido(pedido);
        pedidoDao.close();
        return resultado;
    }

    public int deletarPedido(long codigo) {
        pedidoDao.open();
        int resultado = pedidoDao.deletarPedido(codigo);
        pedidoDao.close();
        return resultado;
    }

    public Pedido buscarPedido(long codigo) {
        pedidoDao.open();
        Pedido pedido = pedidoDao.buscarPedido(codigo);
        pedidoDao.close();
        return pedido;
    }

    public List<Pedido> listarPedidos() {
        pedidoDao.open();
        List<Pedido> listaPedidos = pedidoDao.listarTodos();
        pedidoDao.close();
        return listaPedidos;
    }
}
