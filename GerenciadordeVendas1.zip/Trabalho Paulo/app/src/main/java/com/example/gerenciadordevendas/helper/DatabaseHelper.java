package com.example.gerenciadordevendas.helper;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

public class DatabaseHelper extends SQLiteOpenHelper {

    // Nome e versão do banco de dados
    private static final String DATABASE_NAME = "GerenciadorDeVendas.db";
    private static final int DATABASE_VERSION = 1;

    // Tabelas e colunas
    public static final String TABELA_CLIENTE = "Cliente";
    public static final String COLUNA_CLIENTE_CODIGO = "codigo";
    public static final String COLUNA_CLIENTE_NOME = "nome";
    public static final String COLUNA_CLIENTE_CPF = "cpf";
    public static final String COLUNA_CLIENTE_DATANASC = "dataNasc";

    public static final String TABELA_ENDERECO = "Endereco";
    public static final String COLUNA_ENDERECO_CODIGO = "codigo";
    public static final String COLUNA_ENDERECO_LOGRADOURO = "logradouro";
    public static final String COLUNA_ENDERECO_NUMERO = "numero";
    public static final String COLUNA_ENDERECO_BAIRRO = "bairro";
    public static final String COLUNA_ENDERECO_CIDADE = "cidade";
    public static final String COLUNA_ENDERECO_UF = "uf";
    public static final String COLUNA_ENDERECO_CODIGOCLIENTE = "codigoCliente";

    public static final String TABELA_ITEM = "Item";
    public static final String COLUNA_ITEM_CODIGO = "codigo";
    public static final String COLUNA_ITEM_DESCRICAO = "descricao";
    public static final String COLUNA_ITEM_VALORUNIT = "valorUnit";
    public static final String COLUNA_ITEM_UNIDADEMEDIDA = "unidadeMedida";

    public static final String TABELA_ITEM_PEDIDO = "ItemPedido";
    public static final String COLUNA_ITEMPEDIDO_CODIGO = "codigo";
    public static final String COLUNA_ITEMPEDIDO_CODIGOPEDIDO = "codigoPedido";
    public static final String COLUNA_ITEMPEDIDO_CODIGOITEM = "codigoItem";
    public static final String COLUNA_ITEMPEDIDO_QUANTIDADE = "quantidade";

    public static final String TABELA_PEDIDO = "Pedido";
    public static final String COLUNA_PEDIDO_CODIGO = "codigo";
    public static final String COLUNA_PEDIDO_CODIGOCLIENTE = "codigoCliente";
    public static final String COLUNA_PEDIDO_CODIGOENDERECO = "codigoEndereco";
    public static final String COLUNA_PEDIDO_DATAPEDIDO = "dataPedido";
    public static final String COLUNA_PEDIDO_VALORTOTAL = "valorTotal";
    public static final String COLUNA_PEDIDO_CONDICAOPAGAMENTO = "condicaoPagamento";

    // SQL de criação das tabelas
    private static final String CREATE_TABLE_CLIENTE = "CREATE TABLE " + TABELA_CLIENTE + " (" +
            COLUNA_CLIENTE_CODIGO + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
            COLUNA_CLIENTE_NOME + " TEXT NOT NULL, " +
            COLUNA_CLIENTE_CPF + " TEXT NOT NULL, " +
            COLUNA_CLIENTE_DATANASC + " TEXT);";

    private static final String CREATE_TABLE_ENDERECO = "CREATE TABLE " + TABELA_ENDERECO + " (" +
            COLUNA_ENDERECO_CODIGO + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
            COLUNA_ENDERECO_LOGRADOURO + " TEXT NOT NULL, " +
            COLUNA_ENDERECO_NUMERO + " TEXT, " +
            COLUNA_ENDERECO_BAIRRO + " TEXT, " +
            COLUNA_ENDERECO_CIDADE + " TEXT NOT NULL, " +
            COLUNA_ENDERECO_UF + " TEXT NOT NULL, " +
            COLUNA_ENDERECO_CODIGOCLIENTE + " INTEGER, " +
            "FOREIGN KEY(" + COLUNA_ENDERECO_CODIGOCLIENTE + ") REFERENCES " + TABELA_CLIENTE + "(" + COLUNA_CLIENTE_CODIGO + "));";

    private static final String CREATE_TABLE_ITEM = "CREATE TABLE " + TABELA_ITEM + " (" +
            COLUNA_ITEM_CODIGO + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
            COLUNA_ITEM_DESCRICAO + " TEXT NOT NULL, " +
            COLUNA_ITEM_VALORUNIT + " REAL NOT NULL, " +
            COLUNA_ITEM_UNIDADEMEDIDA + " TEXT NOT NULL);";

    private static final String CREATE_TABLE_ITEM_PEDIDO = "CREATE TABLE " + TABELA_ITEM_PEDIDO + " (" +
            COLUNA_ITEMPEDIDO_CODIGO + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
            COLUNA_ITEMPEDIDO_CODIGOPEDIDO + " INTEGER, " +
            COLUNA_ITEMPEDIDO_CODIGOITEM + " INTEGER, " +
            COLUNA_ITEMPEDIDO_QUANTIDADE + " INTEGER NOT NULL, " +
            "FOREIGN KEY(" + COLUNA_ITEMPEDIDO_CODIGOPEDIDO + ") REFERENCES " + TABELA_PEDIDO + "(" + COLUNA_PEDIDO_CODIGO + "), " +
            "FOREIGN KEY(" + COLUNA_ITEMPEDIDO_CODIGOITEM + ") REFERENCES " + TABELA_ITEM + "(" + COLUNA_ITEM_CODIGO + "));";

    private static final String CREATE_TABLE_PEDIDO = "CREATE TABLE " + TABELA_PEDIDO + " (" +
            COLUNA_PEDIDO_CODIGO + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
            COLUNA_PEDIDO_CODIGOCLIENTE + " INTEGER, " +
            COLUNA_PEDIDO_CODIGOENDERECO + " INTEGER, " +
            COLUNA_PEDIDO_DATAPEDIDO + " TEXT NOT NULL, " +
            COLUNA_PEDIDO_VALORTOTAL + " REAL NOT NULL, " +
            COLUNA_PEDIDO_CONDICAOPAGAMENTO + " TEXT NOT NULL, " +
            "FOREIGN KEY(" + COLUNA_PEDIDO_CODIGOCLIENTE + ") REFERENCES " + TABELA_CLIENTE + "(" + COLUNA_CLIENTE_CODIGO + "), " +
            "FOREIGN KEY(" + COLUNA_PEDIDO_CODIGOENDERECO + ") REFERENCES " + TABELA_ENDERECO + "(" + COLUNA_ENDERECO_CODIGO + "));";

    // Construtor
    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        try {
            db.execSQL(CREATE_TABLE_CLIENTE);
            db.execSQL(CREATE_TABLE_ENDERECO);
            db.execSQL(CREATE_TABLE_ITEM);
            db.execSQL(CREATE_TABLE_ITEM_PEDIDO);
            db.execSQL(CREATE_TABLE_PEDIDO);
            Log.d("DatabaseHelper", "Tabelas criadas com sucesso.");
        } catch (Exception e) {
            Log.e("DatabaseHelper", "Erro ao criar tabelas: " + e.getMessage(), e);
        }
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        try {
            Log.d("DatabaseHelper", "Atualizando banco de dados da versão " + oldVersion + " para " + newVersion);
            db.execSQL("DROP TABLE IF EXISTS " + TABELA_CLIENTE);
            db.execSQL("DROP TABLE IF EXISTS " + TABELA_ENDERECO);
            db.execSQL("DROP TABLE IF EXISTS " + TABELA_ITEM);
            db.execSQL("DROP TABLE IF EXISTS " + TABELA_ITEM_PEDIDO);
            db.execSQL("DROP TABLE IF EXISTS " + TABELA_PEDIDO);
            onCreate(db);
        } catch (Exception e) {
            Log.e("DatabaseHelper", "Erro ao atualizar banco de dados: " + e.getMessage(), e);
        }
    }
}