package com.example.gerenciadordevendas.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.example.gerenciadordevendas.R;
import com.example.gerenciadordevendas.model.Item;
import java.util.List;

public class ItemAdapter extends RecyclerView.Adapter<ItemAdapter.ItemViewHolder> {

    private List<Item> itemList;
    private Context context;
    private OnItemClickListener onItemClickListener;

    // Interface para tratar cliques nos itens
    public interface OnItemClickListener {
        void onItemClick(Item item);
    }

    // Construtor do adapter
    public ItemAdapter(List<Item> itemList, Context context, OnItemClickListener onItemClickListener) {
        this.itemList = itemList;
        this.context = context;
        this.onItemClickListener = onItemClickListener;
    }

    @NonNull
    @Override
    public ItemViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.activity_pedido, parent, false);
        return new ItemViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ItemViewHolder holder, int position) {
        Item item = itemList.get(position);

        // Define os valores para os TextViews
        holder.tvNomeItem.setText(item.getDescricao()); // Corrigido para usar o método getDescricao()
        holder.tvPrecoItem.setText(String.format("R$ %.2f", item.getValorUnit())); // Corrigido para getValorUnit()
        holder.tvQuantidadeItem.setText("N/A"); // Não há campo de quantidade no modelo Item

        // Configura o clique no item
        holder.itemView.setOnClickListener(v -> {
            if (onItemClickListener != null) {
                onItemClickListener.onItemClick(item);
            }
        });
    }

    @Override
    public int getItemCount() {
        return itemList.size();
    }

    // Classe interna para armazenar as referências dos componentes de cada item
    public static class ItemViewHolder extends RecyclerView.ViewHolder {

        TextView tvNomeItem, tvPrecoItem, tvQuantidadeItem;

        public ItemViewHolder(@NonNull View itemView) {
            super(itemView);
            tvNomeItem = itemView.findViewById(R.id.tvNomeItem);
            tvPrecoItem = itemView.findViewById(R.id.tvPrecoItem);
            tvQuantidadeItem = itemView.findViewById(R.id.tvQuantidadeItem);
        }
    }
}
