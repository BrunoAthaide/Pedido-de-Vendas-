package com.example.gerenciadordevendas.controller;



import android.content.Context;

import com.example.gerenciadordevendas.dao.ItemPedidoDao;
import com.example.gerenciadordevendas.model.ItemPedido;

import java.util.List;

public class ItemPedidoController {

    private ItemPedidoDao itemPedidoDao;

    public ItemPedidoController(Context context) {
        itemPedidoDao = new ItemPedidoDao(context);
    }

    // Adicionar um item ao pedido
    public long adicionarItemPedido(ItemPedido itemPedido) {
        itemPedidoDao.open();
        long resultado = itemPedidoDao.inserirItemPedido(itemPedido);
        itemPedidoDao.close();
        return resultado;
    }

    // Atualizar um item do pedido
    public int atualizarItemPedido(ItemPedido itemPedido) {
        itemPedidoDao.open();
        int resultado = itemPedidoDao.atualizarItemPedido(itemPedido);
        itemPedidoDao.close();
        return resultado;
    }

    // Remover um item do pedido
    public int deletarItemPedido(long idItemPedido) {
        itemPedidoDao.open();
        int resultado = itemPedidoDao.deletarItemPedido(idItemPedido);
        itemPedidoDao.close();
        return resultado;
    }

    // Buscar um item específico do pedido
    public ItemPedido buscarItemPedido(long idItemPedido) {
        itemPedidoDao.open();
        ItemPedido itemPedido = itemPedidoDao.buscarItemPedido(idItemPedido);
        itemPedidoDao.close();
        return itemPedido;
    }

    // Listar todos os itens associados a um pedido
    public List<ItemPedido> listarItensDoPedido(long pedidoId) {
        itemPedidoDao.open();
        List<ItemPedido> listaItens = itemPedidoDao.listarItensPorPedido(pedidoId);
        itemPedidoDao.close();
        return listaItens;
    }
}
