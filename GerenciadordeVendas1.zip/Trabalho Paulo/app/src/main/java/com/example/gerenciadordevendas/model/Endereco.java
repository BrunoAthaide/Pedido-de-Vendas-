package com.example.gerenciadordevendas.model;

public class Endereco {
    private int codigo; // Código do endereço (chave primária)
    private String logradouro; // Rua/Logradouro
    private String numero; // Número da residência
    private String bairro; // Bairro
    private String cidade; // Cidade
    private String uf; // Estado (UF)
    private String cep; // Código postal
    private int codigoCliente; // Código do cliente associado (FK)

    // Construtor vazio (padrão)
    public Endereco() {
    }

    // Construtor completo
    public Endereco(int codigo, String logradouro, String numero, String bairro, String cidade, String uf, String cep, int codigoCliente) {
        this.codigo = codigo;
        this.logradouro = logradouro;
        this.numero = numero;
        this.bairro = bairro;
        this.cidade = cidade;
        this.uf = uf;
        this.cep = cep;
        this.codigoCliente = codigoCliente;
    }

    // Construtor simplificado (sem código e códigoCliente)
    public Endereco(String logradouro, String numero, String bairro, String cidade, String uf, String cep) {
        this.logradouro = logradouro;
        this.numero = numero;
        this.bairro = bairro;
        this.cidade = cidade;
        this.uf = uf;
        this.cep = cep;
    }

    // Getters e Setters

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public String getLogradouro() {
        return logradouro;
    }

    public void setLogradouro(String logradouro) {
        this.logradouro = logradouro;
    }

    public String getNumero() {
        return numero;
    }

    public void setNumero(String numero) {
        this.numero = numero;
    }

    public String getBairro() {
        return bairro;
    }

    public void setBairro(String bairro) {
        this.bairro = bairro;
    }

    public String getCidade() {
        return cidade;
    }

    public void setCidade(String cidade) {
        this.cidade = cidade;
    }

    public String getUf() {
        return uf;
    }

    public void setUf(String uf) {
        this.uf = uf;
    }

    public String getCep() {
        return cep;
    }

    public void setCep(String cep) {
        this.cep = cep;
    }

    public int getCodigoCliente() {
        return codigoCliente;
    }

    public void setCodigoCliente(int codigoCliente) {
        this.codigoCliente = codigoCliente;
    }

    // Método simplificado para obter o atributo logradouro como "rua"
    public String getRua() {
        return this.logradouro; // Retorna o valor de logradouro
    }

    // Método toString() para facilitar depuração
    @Override
    public String toString() {
        return "Endereco{" +
                "codigo=" + codigo +
                ", logradouro='" + logradouro + '\'' +
                ", numero='" + numero + '\'' +
                ", bairro='" + bairro + '\'' +
                ", cidade='" + cidade + '\'' +
                ", uf='" + uf + '\'' +
                ", cep='" + cep + '\'' +
                ", codigoCliente=" + codigoCliente +
                '}';
    }

    // Método para validação dos dados
    public boolean isValido() {
        return logradouro != null && !logradouro.isEmpty() &&
                numero != null && !numero.isEmpty() &&
                bairro != null && !bairro.isEmpty() &&
                cidade != null && !cidade.isEmpty() &&
                uf != null && uf.length() == 2 &&
                cep != null && cep.matches("\\d{5}-\\d{3}");
    }
}