package com.example.gerenciadordevendas.dao;


import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;

import com.example.gerenciadordevendas.helper.DatabaseHelper;
import com.example.gerenciadordevendas.model.Item;

import java.util.ArrayList;
import java.util.List;

public class ItemDao {

    private SQLiteDatabase database;
    private DatabaseHelper dbHelper;

    public ItemDao(Context context) {
        dbHelper = new DatabaseHelper(context);
    }

    // Abrir conexão com o banco de dados
    public void open() throws SQLException {
        database = dbHelper.getWritableDatabase();
    }

    // Fechar conexão com o banco de dados
    public void close() {
        dbHelper.close();
    }

    // Inserir um novo item no banco
    public long inserirItem(Item item) {
        ContentValues values = new ContentValues();
        values.put(DatabaseHelper.COLUNA_ITEM_DESCRICAO, item.getDescricao());
        values.put(DatabaseHelper.COLUNA_ITEM_VALORUNIT, item.getValorUnit());
        values.put(DatabaseHelper.COLUNA_ITEM_UNIDADEMEDIDA, item.getUnidadeMedida());

        return database.insert(DatabaseHelper.TABELA_ITEM, null, values);
    }

    // Atualizar um item existente
    public int atualizarItem(Item item) {
        ContentValues values = new ContentValues();
        values.put(DatabaseHelper.COLUNA_ITEM_DESCRICAO, item.getDescricao());
        values.put(DatabaseHelper.COLUNA_ITEM_VALORUNIT, item.getValorUnit());
        values.put(DatabaseHelper.COLUNA_ITEM_UNIDADEMEDIDA, item.getUnidadeMedida());

        return database.update(
                DatabaseHelper.TABELA_ITEM,
                values,
                DatabaseHelper.COLUNA_ITEM_CODIGO + " = ?",
                new String[]{String.valueOf(item.getCodigo())}
        );
    }

    // Deletar um item pelo código
    public int deletarItem(long codigo) {
        return database.delete(
                DatabaseHelper.TABELA_ITEM,
                DatabaseHelper.COLUNA_ITEM_CODIGO + " = ?",
                new String[]{String.valueOf(codigo)}
        );
    }

    // Buscar um item específico pelo código
    public Item buscarItem(long codigo) {
        Cursor cursor = database.query(
                DatabaseHelper.TABELA_ITEM,
                null,
                DatabaseHelper.COLUNA_ITEM_CODIGO + " = ?",
                new String[]{String.valueOf(codigo)},
                null, null, null
        );

        if (cursor != null) {
            cursor.moveToFirst();
            Item item = cursorParaItem(cursor);
            cursor.close();
            return item;
        }
        return null;
    }

    // Listar todos os itens
    public List<Item> listarTodosItens() {
        List<Item> listaItens = new ArrayList<>();
        Cursor cursor = database.query(
                DatabaseHelper.TABELA_ITEM,
                null, null, null, null, null, null
        );

        if (cursor != null) {
            while (cursor.moveToNext()) {
                Item item = cursorParaItem(cursor);
                listaItens.add(item);
            }
            cursor.close();
        }
        return listaItens;
    }

    // Converter o cursor em um objeto Item
    private Item cursorParaItem(Cursor cursor) {
        Item item = new Item();
        item.setCodigo((int) cursor.getLong(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUNA_ITEM_CODIGO)));
        item.setDescricao(cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUNA_ITEM_DESCRICAO)));
        item.setValorUnit(cursor.getDouble(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUNA_ITEM_VALORUNIT)));
        item.setUnidadeMedida(cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUNA_ITEM_UNIDADEMEDIDA)));
        return item;
    }
}
