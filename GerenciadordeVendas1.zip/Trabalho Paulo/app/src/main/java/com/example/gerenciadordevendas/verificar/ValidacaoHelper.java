package com.example.gerenciadordevendas.verificar;

public class ValidacaoHelper {

    // Verificar se o CPF é válido (simplificado, sem algoritmo de validação completa)
    public static boolean validarCPF(String cpf) {
        return cpf != null && cpf.matches("\\d{11}");
    }

    // Verificar se um campo não está vazio
    public static boolean validarCampoVazio(String campo) {
        return campo != null && !campo.trim().isEmpty();
    }
}
