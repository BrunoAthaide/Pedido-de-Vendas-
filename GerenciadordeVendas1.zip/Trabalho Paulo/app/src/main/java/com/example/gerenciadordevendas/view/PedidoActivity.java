package com.example.gerenciadordevendas.view;

import android.os.Bundle;
import android.text.TextUtils;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.gerenciadordevendas.R;
import com.example.gerenciadordevendas.adapter.ItemPedidoAdapter;
import com.example.gerenciadordevendas.model.ItemPedido;

import java.util.ArrayList;
import java.util.List;

public class PedidoActivity extends AppCompatActivity {

    private TextView tvValorTotal;
    private EditText etFrete;
    private Spinner spinnerCliente, spinnerCondicaoPagamento;
    private RecyclerView rvItensPedido;
    private Button btnFinalizarPedido;
    private ItemPedidoAdapter itemPedidoAdapter;
    private List<ItemPedido> listaItensPedido;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pedido);

        inicializarComponentes();
        listaItensPedido = new ArrayList<>(); // Inicializa a lista
        configurarRecyclerView();
        carregarDadosPedido();

        btnFinalizarPedido.setOnClickListener(v -> finalizarPedido());
    }

    private void inicializarComponentes() {
        tvValorTotal = findViewById(R.id.tvValorTotal);
        etFrete = findViewById(R.id.etFrete);
        spinnerCliente = findViewById(R.id.spinnerCliente);
        spinnerCondicaoPagamento = findViewById(R.id.spinnerCondicaoPagamento);
        rvItensPedido = findViewById(R.id.rvItensPedido);
        btnFinalizarPedido = findViewById(R.id.btnFinalizarPedido);
    }

    private void configurarRecyclerView() {
        rvItensPedido.setLayoutManager(new LinearLayoutManager(this)); // Define o layout linear
        itemPedidoAdapter = new ItemPedidoAdapter(listaItensPedido); // Inicializa o adaptador com a lista
        rvItensPedido.setAdapter(itemPedidoAdapter); // Configura o adaptador no RecyclerView
    }

    private void carregarDadosPedido() {
        // Carregar clientes no Spinner
        List<String> listaClientes = obterListaClientes();
        ArrayAdapter<String> clienteAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, listaClientes);
        clienteAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerCliente.setAdapter(clienteAdapter);

        // Carregar condições de pagamento no Spinner
        List<String> listaCondicoesPagamento = obterListaCondicoesPagamento();
        ArrayAdapter<String> condicaoPagamentoAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, listaCondicoesPagamento);
        condicaoPagamentoAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerCondicaoPagamento.setAdapter(condicaoPagamentoAdapter);

        // Adicionar itens de pedido para teste
        ItemPedido item1 = new ItemPedido(1, 1, 101, 2, 10.5, "Item A");
        ItemPedido item2 = new ItemPedido(2, 1, 102, 1, 20.0, "Item B");
        listaItensPedido.add(item1);
        listaItensPedido.add(item2);

        itemPedidoAdapter.notifyDataSetChanged();
    }

    private List<String> obterListaClientes() {
        List<String> clientes = new ArrayList<>();
        clientes.add("Cliente A");
        clientes.add("Cliente B");
        clientes.add("Cliente C");
        return clientes;
    }

    private List<String> obterListaCondicoesPagamento() {
        List<String> condicoesPagamento = new ArrayList<>();
        condicoesPagamento.add("À vista");
        condicoesPagamento.add("Parcelado 2x");
        condicoesPagamento.add("Parcelado 3x");
        return condicoesPagamento;
    }

    private void finalizarPedido() {
        if (TextUtils.isEmpty(etFrete.getText().toString())) {
            Toast.makeText(this, "Informe o valor do frete", Toast.LENGTH_SHORT).show();
            return;
        }

        double frete = Double.parseDouble(etFrete.getText().toString());
        double valorTotal = calcularValorTotal(frete);

        Toast.makeText(this, "Pedido finalizado. Valor total: R$ " + valorTotal, Toast.LENGTH_SHORT).show();
    }

    private double calcularValorTotal(double frete) {
        double totalItens = 0;
        for (ItemPedido item : listaItensPedido) {
            totalItens += item.getQuantidade() * item.getPrecoUnitario();
        }

        double valorTotal = totalItens + frete;
        tvValorTotal.setText(String.format("R$ %.2f", valorTotal));

        return valorTotal;
    }
}
