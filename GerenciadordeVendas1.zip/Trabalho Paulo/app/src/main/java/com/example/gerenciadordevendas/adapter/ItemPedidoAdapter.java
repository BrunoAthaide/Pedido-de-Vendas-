package com.example.gerenciadordevendas.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.gerenciadordevendas.R;
import com.example.gerenciadordevendas.model.ItemPedido;

import java.util.List;

public class ItemPedidoAdapter extends RecyclerView.Adapter<ItemPedidoAdapter.ItemPedidoViewHolder> {

    private List<ItemPedido> listaItens;

    public ItemPedidoAdapter(List<ItemPedido> listaItens) {
        this.listaItens = listaItens;
    }

    @NonNull
    @Override
    public ItemPedidoViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.activity_pedido, parent, false);
        return new ItemPedidoViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ItemPedidoViewHolder holder, int position) {
        ItemPedido item = listaItens.get(position);
        holder.tvNome.setText(item.getNome());
        holder.tvQuantidade.setText(String.valueOf(item.getQuantidade()));
        holder.tvPreco.setText(String.format("R$ %.2f", item.getPreco()));
    }

    @Override
    public int getItemCount() {
        return listaItens.size();
    }

    static class ItemPedidoViewHolder extends RecyclerView.ViewHolder {
        TextView tvNome, tvQuantidade, tvPreco;

        public ItemPedidoViewHolder(@NonNull View itemView) {
            super(itemView);
            tvNome = itemView.findViewById(R.id.tvNome);
            tvQuantidade = itemView.findViewById(R.id.tvQuantidade);
            tvPreco = itemView.findViewById(R.id.tvPreco);
        }
    }
}