package com.example.gerenciadordevendas.view;

import android.content.Intent;
import android.os.Bundle;

import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

import com.example.gerenciadordevendas.R;

public class MainActivity extends AppCompatActivity {

    private Button btnCadastrarCliente;
    private Button btnVisualizarClientes;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Inicializar os botões
        btnCadastrarCliente = findViewById(R.id.btnCadastrarCliente);
        btnVisualizarClientes = findViewById(R.id.btnVisualizarClientes);

        // Definir ação para o botão "Cadastrar Cliente"
        btnCadastrarCliente.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, ClienteActivity.class);
            startActivity(intent);
        });

        // Definir ação para o botão "Visualizar Clientes"
        btnVisualizarClientes.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, ListaClientesActivity.class);
            startActivity(intent);
        });
    }
}