package com.example.gerenciadordevendas.view;

import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.gerenciadordevendas.R;
import com.example.gerenciadordevendas.adapter.ClienteAdapter;
import com.example.gerenciadordevendas.dao.ClienteDao;
import com.example.gerenciadordevendas.model.Cliente;

import java.util.List;

public class ListaClientesActivity extends AppCompatActivity {

    private RecyclerView rvListaClientes;
    private ClienteAdapter clienteAdapter;
    private List<Cliente> listaClientes;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_listaclientes);

        // Inicializar o RecyclerView
        rvListaClientes = findViewById(R.id.rvListaClientes);
        if (rvListaClientes == null) {
            Log.e("ListaClientesActivity", "RecyclerView não encontrado!");
            return;
        }

        rvListaClientes.setLayoutManager(new LinearLayoutManager(this));

        // Carregar dados no RecyclerView
        carregarListaClientes();
    }

    private void carregarListaClientes() {
        try {
            listaClientes = obterListaClientes();

            if (listaClientes != null && !listaClientes.isEmpty()) {
                clienteAdapter = new ClienteAdapter(listaClientes);
                rvListaClientes.setAdapter(clienteAdapter);
            } else {
                Log.e("ListaClientesActivity", "A lista de clientes está vazia ou nula!");
                Toast.makeText(this, "Nenhum cliente encontrado.", Toast.LENGTH_SHORT).show();
            }
        } catch (Exception e) {
            Log.e("ListaClientesActivity", "Erro ao carregar lista de clientes: " + e.getMessage(), e);
            Toast.makeText(this, "Erro ao carregar lista de clientes.", Toast.LENGTH_SHORT).show();
        }
    }

    private List<Cliente> obterListaClientes() {
        ClienteDao clienteDao = new ClienteDao(getApplicationContext());
        return clienteDao.listarClientes();
    }
}