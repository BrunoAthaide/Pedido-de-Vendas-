package com.example.gerenciadordevendas.dao;


import java.util.List;


public interface IGenericDao<T> {

    // Inserir um objeto no banco
    long inserir(T obj);

    // Atualizar um objeto existente
    int atualizar(T obj);

    // Deletar um objeto pelo ID
    int deletar(long id);

    // Buscar um objeto pelo ID
    T buscarPorId(long id);

    // Listar todos os objetos
    List<T> listarTodos();
}
