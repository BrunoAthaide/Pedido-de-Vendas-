package com.example.gerenciadordevendas.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.gerenciadordevendas.R;
import com.example.gerenciadordevendas.model.Cliente;

import java.util.List;

public class ClienteAdapter extends RecyclerView.Adapter<ClienteAdapter.ClienteViewHolder> {

    private final List<Cliente> listaClientes;

    // Construtor
    public ClienteAdapter(List<Cliente> listaClientes) {
        this.listaClientes = listaClientes;
    }

    @NonNull
    @Override
    public ClienteViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        // Inflando o layout do item
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_cliente, parent, false); // Aqui foi corrigido para usar o item_cliente.xml
        return new ClienteViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull ClienteViewHolder holder, int position) {
        // Configurando os valores para os TextViews
        Cliente cliente = listaClientes.get(position);
        holder.tvNomeCliente.setText(cliente.getNome());
        holder.tvEmailCliente.setText(cliente.getEmail());
    }

    @Override
    public int getItemCount() {
        return listaClientes.size();
    }

    // ViewHolder interno
    public static class ClienteViewHolder extends RecyclerView.ViewHolder {
        TextView tvNomeCliente, tvEmailCliente;

        public ClienteViewHolder(@NonNull View itemView) {
            super(itemView);
            tvNomeCliente = itemView.findViewById(R.id.tvNomeCliente);
            tvEmailCliente = itemView.findViewById(R.id.tvEmailCliente);
        }
    }
}
