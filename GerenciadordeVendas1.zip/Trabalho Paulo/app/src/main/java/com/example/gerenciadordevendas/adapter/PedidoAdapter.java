package com.example.gerenciadordevendas.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.gerenciadordevendas.R;
import com.example.gerenciadordevendas.model.Pedido;

import java.util.List;

public class PedidoAdapter extends RecyclerView.Adapter<PedidoAdapter.PedidoViewHolder> {

    private List<Pedido> pedidoList;
    private Context context;
    private OnPedidoClickListener onPedidoClickListener;

    // Interface para cliques em itens
    public interface OnPedidoClickListener {
        void onPedidoClick(Pedido pedido);
    }

    // Construtor
    public PedidoAdapter(List<Pedido> pedidoList, Context context, OnPedidoClickListener onPedidoClickListener) {
        this.pedidoList = pedidoList;
        this.context = context;
        this.onPedidoClickListener = onPedidoClickListener;
    }

    @NonNull
    @Override
    public PedidoViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_cliente, parent, false);
        return new PedidoViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull PedidoViewHolder holder, int position) {
        Pedido pedido = pedidoList.get(position);

        // Definir os valores para os TextViews
        holder.tvNumeroPedido.setText(String.valueOf(pedido.getNumeroPedido()));
        holder.tvDataPedido.setText(pedido.getDataPedido());
        holder.tvValorTotal.setText(String.format("R$ %.2f", pedido.getValorTotal()));

        // Configurar clique no item
        holder.itemView.setOnClickListener(v -> {
            if (onPedidoClickListener != null) {
                onPedidoClickListener.onPedidoClick(pedido);
            }
        });
    }

    @Override
    public int getItemCount() {
        return pedidoList.size();
    }

    // Classe interna para ViewHolder
    public static class PedidoViewHolder extends RecyclerView.ViewHolder {

        TextView tvNumeroPedido, tvDataPedido, tvValorTotal;

        public PedidoViewHolder(@NonNull View itemView) {
            super(itemView);
            tvNumeroPedido = itemView.findViewById(R.id.tvNumeroPedido);
            tvDataPedido = itemView.findViewById(R.id.tvDataPedido);
            tvValorTotal = itemView.findViewById(R.id.tvValorTotal);
        }
    }
}
