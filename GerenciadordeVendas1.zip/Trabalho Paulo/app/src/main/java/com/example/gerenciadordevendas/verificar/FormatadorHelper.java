package com.example.gerenciadordevendas.verificar;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class FormatadorHelper {

    // Formatar CPF
    public static String formatarCPF(String cpf) {
        if (cpf.length() == 11) {
            return cpf.substring(0, 3) + "." + cpf.substring(3, 6) + "." + cpf.substring(6, 9) + "-" + cpf.substring(9, 11);
        }
        return cpf;
    }

    // Formatar data para o padrão "dd/MM/yyyy"
    public static String formatarData(Date data) {
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy", Locale.getDefault());
        return dateFormat.format(data);
    }
}
